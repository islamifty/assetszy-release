const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('resolveAPI', {
    // Queries active project name in DaVinci Resolve
    getProjectName: () => ipcRenderer.invoke('resolve:getProjectName'),
    
    downloadAsset: (firstArg, url, filename) => {
        const customPath = localStorage.getItem('download_cache_path') || '';
        if (typeof firstArg === 'object' && firstArg !== null) {
            return ipcRenderer.invoke('assets:download', { ...firstArg, customPath });
        }
        return ipcRenderer.invoke('assets:download', { id: firstArg, url, filename, customPath });
    },
    
    // Select custom download folder directory
    selectFolder: (currentPath) => ipcRenderer.invoke('dialog:select-folder', currentPath),
    
    // Open path in OS explorer
    openFolder: (pathUrl) => ipcRenderer.invoke('shell:open-path', pathUrl),
    
    // Event listener to track file downloads in real-time
    onDownloadProgress: (callback) => {
        const subscription = (event, value) => callback(value);
        ipcRenderer.on('download-progress', subscription);
        
        // Return unsubscribe function
        return () => {
            ipcRenderer.removeListener('download-progress', subscription);
        };
    },

    // Manually trigger media pool import
    importMedia: (filePath) => ipcRenderer.invoke('resolve:importMedia', filePath),

    // Dynamic Online Update Verification
    checkUpdate: () => ipcRenderer.invoke('app:check-update'),

    // Cleans up Resolve scripting interfaces
    cleanup: () => ipcRenderer.invoke('resolve:cleanup')
});
