#!/bin/bash

# Clear terminal screen
clear

# Navigate to the script's directory (handles double-click execution path context)
cd "$(dirname "$0")"

echo "===================================================="
echo "  Assetszy macOS DaVinci Resolve Plugin Installer"
echo "===================================================="
echo ""

# Define macOS Target Directory paths
GLOBAL_DIR="/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/com.assetszy.resolve.plugin"
USER_DIR="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/com.assetszy.resolve.plugin"

# Detect and choose appropriate path
if [ -d "$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve" ]; then
    INSTALL_DIR="$USER_DIR"
else
    INSTALL_DIR="$GLOBAL_DIR"
fi

echo "Target Destination: $INSTALL_DIR"
echo "Creating directory structures..."
mkdir -p "$INSTALL_DIR"

# Clean old installation if exists
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
    mkdir -p "$INSTALL_DIR"
fi

# Copy all compilation assets
echo "Copying secure plugin bundles..."
if [ -d "dist-plugin" ]; then
    cp -R dist-plugin/* "$INSTALL_DIR/"
else
    # Fallback to copy current folder assets if distributed as standalone package
    cp -R * "$INSTALL_DIR/" 2>/dev/null
fi

# Remove Windows C++ native binary if exists to avoid conflicts on macOS
if [ -f "$INSTALL_DIR/WorkflowIntegration.node" ]; then
    rm "$INSTALL_DIR/WorkflowIntegration.node"
fi

# Clear macOS Gatekeeper Quarantine flag for all copied files to prevent unsigned app errors
echo "Bypassing macOS security Gatekeeper quarantine..."
if [ -d "$INSTALL_DIR" ]; then
    xattr -cr "$INSTALL_DIR" 2>/dev/null
    chmod -R 755 "$INSTALL_DIR" 2>/dev/null
    echo "[SUCCESS] Gatekeeper quarantine cleared for Assetszy!"
fi

echo ""
echo "===================================================="
echo "  Assetszy Plugin Installed Successfully on macOS!"
echo "  Please restart DaVinci Resolve Studio."
echo "  Open via: Workspace > Workflow Integrations"
echo "===================================================="
echo ""
echo "Press [Enter] to exit..."
read -r
