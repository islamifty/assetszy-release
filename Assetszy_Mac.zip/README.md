# 🌌 Assetszy — Premium DaVinci Resolve Stock Integration

Assetszy is an enterprise-grade Workflow Integration Plugin for **DaVinci Resolve Studio (Windows & macOS)**. It allows editors to search, preview, download, and instantly import premium stock videos, photos, transparent vectors, audio, and YouTube assets directly into their active DaVinci Resolve media pool and timeline without leaving the editor.

---

## ✨ Key Features
* 📹 **Ultra-HD Video & Stock Search:** Search and preview millions of premium cinematic videos and photos from Pexels & Pixabay.
* 🎨 **Transparent Vectors & Illustrations:** Specialized transparent PNG search filter designed for motion graphics and editing overlay assets.
* 🎵 **Luxurious Ambient Music Player:** Real-time waveform audio visualizer and rotating vinyl disk for audio/SFX previews.
* 📥 **Zero-Setup YouTube Downloader:** Downloader with dynamic Cobalt API servers that handles video and audio-only extraction.
* ⚡ **Seamless Auto-Timeline Import:** Media imports instantly into DaVinci Resolve without disrupting your current editing page workflow.

---

## 🚀 Installation Guide

### 💻 Windows Installation (easiest)
1. **Download** the single-file installer: [**`Assetszy_Setup.exe`**](https://github.com/islamifty/assetszy-release/raw/main/Assetszy_Setup.exe)
2. **Double-click** the installer.
3. Click **Install** (it will automatically locate DaVinci Resolve's workflow folder).
4. Restart **DaVinci Resolve Studio**.
5. Open via: **Workspace > Workflow Integrations > Assetszy**.

---

### 🍎 macOS Installation (Gatekeeper Bypassed)
Apple Gatekeeper security blocks unsigned plugins. Follow these simple steps to install:
1. **Download** the zip package: [**`Assetszy_Mac.zip`**](https://github.com/islamifty/assetszy-release/raw/main/Assetszy_Mac.zip)
2. **Extract** the zip file.
3. Open the folder and **Double-click** on [**`install-mac.command`**](https://github.com/islamifty/assetszy-release/raw/main/install-mac.command) (this opens a terminal window, automatically installs the plugin, and bypasses macOS unsigned developer warnings).
4. Restart **DaVinci Resolve Studio**.
5. Open via: **Workspace > Workflow Integrations > Assetszy**.

---

## 🛠️ Offline Gatekeeper Bypass (If macOS blocks manually)
If you manually copied the folder and macOS displays the *"WorkflowIntegration cannot be opened because developer cannot be verified"* warning, run this command in your Mac Terminal:
```bash
xattr -cr "$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Workflow Integration Plugins/com.assetszy.resolve.plugin"
```

---

## 📄 License & Terms
All rights reserved. Proprietary software developed for DaVinci Resolve Studio Workflow Integrations. Unauthorized redistribution or reverse-engineering is strictly prohibited under global copyright laws.
